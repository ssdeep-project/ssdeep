
/* Fuzzy Hashing by Jesse Kornblum
   Copyright (C) 2008 ManTech International Corporation

   $Id: ssdeep.h 61 2008-02-22 23:18:59Z jessekornblum $ 
*/

#ifndef __SSDEEP_H
#define __SSDEEP_H

#include "main.h"

#ifdef __GLIBC__
extern char *__progname;
#else 
char *__progname;
#endif



#endif  // #ifndef __SSDEEP_H
